<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package WallPress
 * @since WallPress 1.0.3
 */
?>


<!-- Main -->
<?php wp_footer(); ?>

</body>
</html>