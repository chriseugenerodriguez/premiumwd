<?php
$autosubject="This is test message";
$name="dropcapb37fc3df8ea50175b0a52d1005e611a9.png";
$type="image/png";
$autofrom="srinivas_nagidi@yahoo.co.in";
$automessage="dsafsdafsdafsadfsdf";
$attachment="/home/monster/public_html/scripts/uploads/dropcapb37fc3df8ea50175b0a52d1005e611a9.png";
?>
