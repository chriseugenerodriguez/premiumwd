<?php get_header(); ?>
<?php putRevSlider("home"); ?>
<?php get_footer(); ?>
