<html>
<head>
<title>Activate Theme</title>
</head>
<body>
<p style="text-align:center;margin:20% auto;background-color: #FCFCFC;border: 1px solid #E0E0E0;border-radius:50px; -moz-border-radius:50px; -webkit-border-radius:50px;box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.03);-moz-box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.03);-webkit-box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.03);padding: 15px;width:300px;font-family:Arial, Helvetica, sans-serif;font-size:13px;"><strong>Theme not activated</strong></p>
</body>
</html>
