<?php
/*
Plugin Name: Rotating Testimonials
Version: 0.1
Description: Rotating Testimonials is a plugin that lets you add rotating testimonials in WordPress
*/

add_action('init', 'wpb_register_cpt_testimonial');

function wpb_register_cpt_testimonial ()

{

     $labels = array('name' => _x('Testimonials', 'testimonial'), 

    'singular_name' => _x('Testimonial', 'testimonial'), 
    'add_new' => _x('Add New', 'testimonial'), 
    'add_new_item' => _x('Add New Testimonial', 'testimonial'), 
    'edit_item' => _x('Edit Testimonial', 'testimonial'), 
    'new_item' => _x('New Testimonial', 'testimonial'), 
    'view_item' => _x('View Testimonial', 'testimonial'), 
    'search_items' => _x('Search Testimonials', 'testimonial'), 
    'not_found' => _x('No Testimonials Tound', 'testimonial'), 
    'not_found_in_trash' => _x('No Testimonials Found in Trash', 'testimonial'), 
    'parent_item_colon' => _x('Parent Testimonial:', 'testimonial'), 
    'menu_name' => _x('Testimonials', 'testimonial'));
    $args = array('labels' => $labels, 'hierarchical' => false, 
    'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 
    'custom-fields', 'revisions'), 'public' => true, 'show_ui' => true, 
    'show_in_menu' => true, 'show_in_nav_menus' => true, 
    'publicly_queryable' => true, 'exclude_from_search' => false, 
    'has_archive' => true, 'query_var' => true, 'can_export' => true, 
    'rewrite' => true, 'capability_type' => 'post');

    wp_enqueue_script('testimonial-slider', plugin_dir_url(__FILE__).'testimonials.js', array ('jquery'), null, true);

    register_post_type('testimonial', $args);
}



$key = "testimonial";
$meta_boxes = array(

"person-name" => array("name" => "person-name", "title" => "Person's Name", 
"description" => "Enter the name of the person who gave you the testimonial."), 
"position" => array("name" => "position", "title" => "Position in Company", 
"description" => "Enter their position in their specific company."), 
"company" => array("name" => "company", "title" => "Company Name", 
"description" => "Enter the client Company Name"), 
"link" => array("name" => "link", "title" => "Client Link", 
"description" => "Enter the link to client's site, or you can enter the link to your portfolio page where you have the client displayed."));

function wpb_create_meta_box ()
{
    global $key;

    if (function_exists('add_meta_box'))
    {
        add_meta_box('new-meta-boxes', ucfirst($key) . ' Information', 'display_meta_box', 'testimonial', 'normal', 'high');
    }
}

function display_meta_box ()
{
    global $post, $meta_boxes, $key;
    ?>
<div class="form-wrap">
  <?php

    wp_nonce_field(plugin_basename(__FILE__), $key . '_wpnonce', false, true);

    foreach ($meta_boxes as $meta_box)
    {
        $data = get_post_meta($post->ID, $key, true);

        ?>
  <div class="form-field form-required">
    <label for="<?php echo $meta_box['name']; ?>"><?php echo $meta_box['title']; ?></label>
    <input type="text" name="<?php echo $meta_box['name']; ?>" value="<?php echo htmlspecialchars($data[$meta_box['name']]); ?>" />
    <p><?php echo $meta_box['description']; ?></p>
  </div>
  <?php

    }

    ?>
</div>
<?php

}

function wpb_save_meta_box ($post_id)
{
    global $post, $meta_boxes, $key;
    foreach ($meta_boxes as $meta_box)
    {
        $data[$meta_box['name']] = $_POST[$meta_box['name']];
    }
    if (!wp_verify_nonce($_POST[$key . '_wpnonce'], plugin_basename(__FILE__)))
        return $post_id;
    if (!current_user_can('edit_post', $post_id))
        return $post_id;

    update_post_meta($post_id, $key, $data);
}

add_action('admin_menu', 'wpb_create_meta_box');
add_action('save_post', 'wpb_save_meta_box');

function wpb_display_testimonials ($title = '', $limit_num = 5)
{

    $plugin_dir_url = plugin_dir_url(__FILE__);

    //$bg_img = (empty($img)) ? '' : '';//'background: url('.$img.');';

?>
<script language="javascript"> 

jQuery(document).ready(function($) {
	$("#testimonials").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: false,
  infinite: false,
  adaptiveHeight: true,
  autoplaySpeed: 2000
 });
		
});

</script>';

<style type="text/css">
#testimonials h3.testimonial-header-title{font-size:19px;font-weight:700;margin:5px 0 11px;min-height:25px}#testimonials h4{background-image:url(<?php echo $plugin_dir_url ?>testimonials-bg.png);background-position:left top;background-repeat:no-repeat;display:block;font-size:12px;height:30px;margin-top:-1px;padding:10px 0 0 70px}#testimonials .slick-prev{background-position:-10px -4px;right:20px}#testimonials .slick-next{background-position:-49px -4px;right:0}#testimonials .slick-prev:hover{background-position:-10px -41px}#testimonials .slick-next:hover{background-position:-49px -41px}#testimonials .slick-prev,#testimonials .slick-next{background-image:url(<?php echo $plugin_dir_url ?>navigation.png);display:block;font-size:0;height:26px;line-height:0;width:22px;background-color:transparent;border:none;top:-46px;position:absolute}#testimonials .testimonial-quote{border:1px solid #ddd;box-shadow:0 1px 1px 0 rgba(180,180,180,0.1);line-height:21px;margin:0;padding:20px}	 .slick-slider{position:relative;display:block;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-touch-callout:none;-khtml-user-select:none;-ms-touch-action:pan-y;touch-action:pan-y;-webkit-tap-highlight-color:transparent}.slick-list{position:relative;display:block;overflow:hidden;margin:0;padding:0}.slick-list:focus{outline:none}.slick-list.dragging{cursor:pointer;cursor:hand}.slick-slider .slick-track,.slick-slider .slick-list{-webkit-transform:translate3d(0,0,0);-moz-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);-o-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.slick-track{position:relative;top:0;left:0;display:block}.slick-loading .slick-track{visibility:hidden}.slick-slide{display:none;float:left;height:100%;min-height:1px}[dir="rtl"] .slick-slide{float:right}.slick-slide img{display:block}.slick-slide.slick-loading img{display:none}.slick-slide.dragging img{pointer-events:none}.slick-initialized .slick-slide{display:block}.slick-loading .slick-slide{visibility:hidden}.slick-vertical .slick-slide{display:block;height:auto;border:1px solid transparent}.slick-arrow.slick-hidden{display:none}</style>';
</style>
  <h3 class="testimonial-header-title"><?php echo $title; ?></h3>
<div id="testimonials">
    <?php

    $args = array('post_type' => 'testimonial', 'posts_per_page' => 100, 'orderby' => 'menu_order', 'order' => 'ASC');
    $loop = new WP_Query($args);

    if ($loop->have_posts()) {
        while ($loop->have_posts() && $count < $limit_num){
            $loop->the_post();
            $data = get_post_meta($loop->post->ID, 'testimonial', true);
        ?>
    <div>
      <p class="testimonial-quote">
        <?php the_content(); ?>
      </p>
      <h4 class="slidehed"><?php echo $data['person-name'];?>,&nbsp;<?php echo $data['position'];?>,&nbsp; <a href="<?php echo $data['link'];?>" title="<?php echo $data['company'];?>"><?php echo $data['company'];?></a></h4>
    </div>
    <?php

        }
    }
    ?>
</div>
<?php 

}

function wpb_get_display_testimonials ($title = '', $limit_num = 5)
{
    $html = '';
    $plugin_dir_url = plugin_dir_url(__FILE__);

    $html .= '

<script language="javascript"> 

jQuery(document).ready(function($) {
	$("#testimonials").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: false,
  infinite: false,
  adaptiveHeight: true,
  autoplaySpeed: 2000
 });
		
});

</script>';

    $html .= '<style type="text/css">
#testimonials h3.testimonial-header-title{font-size:19px;font-weight:700;margin:5px 0 11px;min-height:25px}#testimonials h4{background-image:url(' . $plugin_dir_url . 'testimonials-bg.png);background-position:left top;background-repeat:no-repeat;display:block;font-size:12px;height:30px;margin-top:-1px;padding:10px 0 0 70px}#testimonials .slick-prev{background-position:-10px -4px;right:20px}#testimonials .slick-next{background-position:-49px -4px;right:0}#testimonials .slick-prev:hover{background-position:-10px -41px}#testimonials .slick-next:hover{background-position:-49px -41px}#testimonials .slick-prev,#testimonials .slick-next{background-image:url(' . $plugin_dir_url . '/navigation.png);display:block;font-size:0;height:26px;line-height:0;width:22px;background-color:transparent;border:none;top:-46px;position:absolute}#testimonials .testimonial-quote{border:1px solid #ddd;box-shadow:0 1px 1px 0 rgba(180,180,180,0.1);line-height:21px;margin:0;padding:20px}	 .slick-slider{position:relative;display:block;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-touch-callout:none;-khtml-user-select:none;-ms-touch-action:pan-y;touch-action:pan-y;-webkit-tap-highlight-color:transparent}.slick-list{position:relative;display:block;overflow:hidden;margin:0;padding:0}.slick-list:focus{outline:none}.slick-list.dragging{cursor:pointer;cursor:hand}.slick-slider .slick-track,.slick-slider .slick-list{-webkit-transform:translate3d(0,0,0);-moz-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);-o-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.slick-track{position:relative;top:0;left:0;display:block}.slick-loading .slick-track{visibility:hidden}.slick-slide{display:none;float:left;height:100%;min-height:1px}[dir="rtl"] .slick-slide{float:right}.slick-slide img{display:block}.slick-slide.slick-loading img{display:none}.slick-slide.dragging img{pointer-events:none}.slick-initialized .slick-slide{display:block}.slick-loading .slick-slide{visibility:hidden}.slick-vertical .slick-slide{display:block;height:auto;border:1px solid transparent}.slick-arrow.slick-hidden{display:none}</style>';

    $html .= '<h3 class="testimonial-header-title">' . $title . '</h3>';
    $html .= '<div id="testimonials">';

    $args = array('post_type' => 'testimonial', 'posts_per_page' => 100, 'orderby' => 'menu_order', 'order' => 'ASC');
    $loop = new WP_Query($args);

    if ($loop->have_posts()) {
        while ($loop->have_posts() && $count < $limit_num){
            $loop->the_post();
            $data = get_post_meta($loop->post->ID, 'testimonial', true);
    	    $html .= '<div><p class="testimonial-quote">'.get_the_content().'</p>';
        	$html .= '<h4 class="slidehed">'.$data['person-name'].',&nbsp;'.$data['position'].',&nbsp;
        		<a href="'.$data['link'].'" title="'.$data['company'].'">'.$data['company'].'</a></h4></div>';
        }
    }
	$html .= '</div>';

	return $html;
}

function wpb_lists_testimonials ($per_page = 10)
{
?>
<style type="text/css">
.slick-slider{position:relative;display:block;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-touch-callout:none;-khtml-user-select:none;-ms-touch-action:pan-y;touch-action:pan-y;-webkit-tap-highlight-color:transparent}.slick-list{position:relative;display:block;overflow:hidden;margin:0;padding:0}.slick-list:focus{outline:none}.slick-list.dragging{cursor:pointer;cursor:hand}.slick-slider .slick-track,.slick-slider .slick-list{-webkit-transform:translate3d(0,0,0);-moz-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);-o-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.slick-track{position:relative;top:0;left:0;display:block}.slick-track:before,.slick-track:after{display:table;content:''}.slick-track:after{clear:both}.slick-loading .slick-track{visibility:hidden}.slick-slide{display:none;float:left;height:100%;min-height:1px}[dir='rtl'] .slick-slide{float:right}.slick-slide img{display:block}.slick-slide.slick-loading img{display:none}.slick-slide.dragging img{pointer-events:none}.slick-initialized .slick-slide{display:block}.slick-loading .slick-slide{visibility:hidden}.slick-vertical .slick-slide{display:block;height:auto;border:1px solid transparent}.slick-arrow.slick-hidden{display:none}</style>
<div id="testimonials">
    <?php

    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $args = array( 'post_type' => 'testimonial', 'posts_per_page' => $per_page, 'orderby'   => 'menu_order', 'paged'=>$paged, 'order' => 'ASC' );
    $loop = new WP_Query( $args );

    if ( $loop->have_posts() ) : while ( $loop->have_posts() ) : $loop->the_post();

    $data = get_post_meta( $loop->post->ID, 'testimonial', true );

    ?>
    <div>
      <h3 class="testimonial-header-title"><a href="<?php echo the_permalink(); ?>"><?php echo the_title(); ?></a></h3>
      <p class="testimonial-quote">
        <?php the_content(); ?>
      </p>
      <h4 class="slidehed"><?php echo $data['person-name'];?>,&nbsp;<?php echo $data['position'];?>,&nbsp; <a href="<?php echo $data['link'];?>" title="<?php echo $data['company'];?>"><?php echo $data['company'];?></a></h4>
    </div>
    <hr />
    <?php

        endwhile; 

    else:

    ?>
    <li class="t_item">
      <p class="error-not-found">Sorry, no testimonia entries yet.</p>
    </li>
    <?php

    endif;

?>
</div>
<?php 



    // pagenation
    $range = 3;
    $showitems = ($range * 2)+1; 
    $pages = ($loop->max_num_pages) ? $loop->max_num_pages : 1;
    if ($pages > 1)

    {
         echo "<div class='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div>\n";
    }
}



function testimonal_pagination($pages = '', $range = 2)
{  
     $showitems = ($range * 2)+1;  
	global $wp_query, $wp_rewrite;
	$wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   

     if(1 != $pages)
     {
         echo "<div class='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div>\n";
     }
}
?>
